	EZCalendar v0.9.1 Created by Stewart Orr (www.qodo.co.uk)

	http://www.qodo.co.uk/blog/javascript-pop-up-dhtml-calendar-using-css/

	Created: Oct 2006
	Updated: January 2008
	
	You are free to use this wherever you like, maybe you could contact me
	to let me know where/how you are using it.

	Usage:
		- Expects dates in the UK format DD/MM/YYYY.
		- Uses JS and CSS file to determine appearance
		- CSS File should have all necessary styles to ensure it appears
		correctly in YOUR page. Remember other CSS styles will affect this...
		
	To Do:
		- Position the calendar differently if it spills over the viewable space.
		- Improve Code
		- Allow different date separators
		- Allow different date formats (YYYY/MM/DD and MM/DD/YYYY)
		- Allow for date restrictions
		
	ChangeLog:
		- Jan 2008: Improvements to code and added fadeOut effect, added tooltips
		- March 2007: Added fading in effect
		- February 2007: Updated and improved coding
		- October 2006: created first version